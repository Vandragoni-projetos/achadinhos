const fields = {
  csrf: document.getElementById('csrf'),
  cookie: document.getElementById('cookie'),
};

const statusEl = document.getElementById('status');

function loadData() {
  chrome.storage.local.get(['mlData'], (result) => {
    const data = result.mlData || {};
    fields.csrf.value = data.xcsrf || '';
    fields.cookie.value = data.cookie || '';

    document.querySelectorAll('.card').forEach((card) => {
      const field = card.dataset.field;
      const map = { csrf: 'xcsrf', cookie: 'cookie' };
      const key = map[field];
      const val = data[key];
      card.classList.toggle('has-data', !!val);
    });

    if (data.lastUpdate) {
      const ago = Math.round((Date.now() - data.lastUpdate) / 1000);
      statusEl.textContent =
        ago < 60
          ? `Capturado há ${ago}s`
          : `Capturado às ${new Date(data.lastUpdate).toLocaleTimeString('pt-BR')}`;
    } else {
      statusEl.textContent = 'Gere um link no Link Builder para capturar os dados.';
    }
  });
}

function copyToClipboard(text) {
  return navigator.clipboard.writeText(text);
}

document.querySelectorAll('.btn-copy').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.copy;
    const el = fields[id];
    const text = el.value.trim();
    if (!text) return;
    try {
      await copyToClipboard(text);
      btn.classList.add('copied');
      btn.querySelector('.text').textContent = 'Copiado!';
      setTimeout(() => {
        btn.classList.remove('copied');
        btn.querySelector('.text').textContent = 'Copiar';
      }, 1500);
    } catch (_) {
      btn.querySelector('.text').textContent = 'Erro';
      setTimeout(() => (btn.querySelector('.text').textContent = 'Copiar'), 1500);
    }
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.mlData) loadData();
});

loadData();
