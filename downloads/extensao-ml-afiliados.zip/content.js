(function () {
  const CREATE_LINK = 'createLink';

  const script = document.createElement('script');
  script.textContent = `
(function() {
  const CREATE_LINK = 'createLink';

  const origFetch = window.fetch;
  window.fetch = function(url, opts) {
    const urlStr = typeof url === 'string' ? url : url?.url || '';
    if (urlStr.includes(CREATE_LINK)) {
      try {
        const csrf = opts?.headers?.get?.('x-csrf-token') || opts?.headers?.['x-csrf-token'] || '';
        const cookie = opts?.headers?.get?.('cookie') || opts?.headers?.['cookie'] || '';
        if (csrf || cookie) {
          window.postMessage({ type: 'ML_AFILIADOS_CAPTURE', data: { csrf, cookie } }, '*');
        }
      } catch (e) {}
    }
    return origFetch.apply(this, arguments);
  };

  const XHROpen = XMLHttpRequest.prototype.open;
  const XHRSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url) {
    this._url = url;
    this._method = method;
    return XHROpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body) {
    const url = this._url || '';
    if (url.includes(CREATE_LINK)) {
      try {
        const csrf = this.getRequestHeader?.('x-csrf-token') || '';
        const cookie = this.getRequestHeader?.('cookie') || '';
        if (csrf || cookie) {
          window.postMessage({ type: 'ML_AFILIADOS_CAPTURE', data: { csrf, cookie } }, '*');
        }
      } catch (e) {}
    }
    return XHRSend.apply(this, arguments);
  };

  const origSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    this._headers = this._headers || {};
    this._headers[name.toLowerCase()] = value;
    return origSetRequestHeader.apply(this, arguments);
  };
  XMLHttpRequest.prototype.getRequestHeader = function(name) {
    return (this._headers || {})[name.toLowerCase()] || '';
  };
})();
`;
  (document.head || document.documentElement).appendChild(script);
  script.remove();

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.type !== 'ML_AFILIADOS_CAPTURE') return;
    const d = e.data.data || {};
    chrome.storage.local.get(['mlData'], (prev) => {
      const data = prev.mlData || {};
      if (d.csrf) data.xcsrf = d.csrf;
      if (d.cookie) data.cookie = d.cookie;
      data.lastUpdate = Date.now();
      chrome.storage.local.set({ mlData: data });
    });
  });
})();
