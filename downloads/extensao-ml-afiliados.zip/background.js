const CREATE_LINK_URL = 'createLink';

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (!details.url.includes(CREATE_LINK_URL)) return;

    const headers = {};
    for (const h of details.requestHeaders || []) {
      const name = h.name.toLowerCase();
      if (name === 'x-csrf-token') headers.csrf = h.value;
      if (name === 'cookie') headers.cookie = h.value;
    }

    chrome.storage.local.get(['mlData'], (prev) => {
      const data = prev.mlData || {};
      if (headers.csrf) data.xcsrf = headers.csrf;
      if (headers.cookie) data.cookie = headers.cookie;
      data.lastUpdate = Date.now();
      chrome.storage.local.set({ mlData: data });
    });
  },
  { urls: ['*://*.mercadolivre.com.br/*', '*://*.mercadolibre.com/*'] },
  ['requestHeaders', 'extraHeaders']
);

