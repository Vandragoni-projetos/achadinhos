<?php
// Script para gerar ícones da extensão (execute: php criar-icones.php)
$sizes = [16, 48, 128];
$dir = __DIR__ . '/icons';
if (!is_dir($dir)) mkdir($dir);

foreach ($sizes as $size) {
    $img = imagecreatetruecolor($size, $size);
    if (!$img) die("Erro ao criar imagem {$size}x{$size}\n");
    $orange = imagecolorallocate($img, 255, 107, 53);
    imagefill($img, 0, 0, $orange);
    imagepng($img, "{$dir}/icon{$size}.png");
    imagedestroy($img);
}
echo "Ícones criados em {$dir}\n";
