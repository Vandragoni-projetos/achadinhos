# ML Afiliados - Extensão Chrome

Extrai **Tag de Afiliado**, **x-csrf-token** e **Cookie completo** das requisições `createLink` no Link Builder do Mercado Livre.

## Instalação

1. Abra o Chrome ou Edge e acesse `chrome://extensions` (ou `edge://extensions`)
2. Ative o **Modo desenvolvedor** (canto superior direito)
3. Clique em **Carregar sem compactação**
4. Selecione a pasta `extensao-ml-afiliados`

## Como usar

1. Abra o Chrome/Edge em modo anônimo e faça login no Mercado Livre
2. Acesse: [Link Builder](https://www.mercadolivre.com.br/afiliados/linkbuilder)
3. Gere um link de afiliado manualmente na página
4. Clique no ícone da extensão para abrir o popup
5. Use os botões **Copiar** para cada campo e cole no painel

## Ícones

Para recriar os ícones:
```bash
php criar-icones.php
```
